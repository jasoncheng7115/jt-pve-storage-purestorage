# Pure Storage Fibre Channel Management Utilities
# Copyright (c) 2026 Jason Cheng (Jason Tools)
# Licensed under the MIT License

package PVE::Storage::Custom::PureStorage::FC;

use strict;
use warnings;

use Carp qw(croak);
use File::Basename qw(basename);

use PVE::Storage::Custom::PureStorage::Multipath qw(
    sysfs_write_with_timeout
    sysfs_read_with_timeout
);

use Exporter qw(import);

our @EXPORT_OK = qw(
    get_fc_wwpns
    get_fc_wwpns_raw
    get_fc_wwnn
    get_fc_hosts
    get_fc_targets
    rescan_fc_hosts
    is_fc_available
    format_wwn
    parse_wwn
    normalize_wwn
);

# Constants
use constant {
    FC_HOST_PATH   => '/sys/class/fc_host',
    FC_REMOTE_PATH => '/sys/class/fc_remote_ports',
};

# Read a sysfs attribute with a bounded timeout.
#
# This used to be a bare open()+readline. Every other sysfs read in the plugin
# goes through sysfs_read_with_timeout() because a read of /sys can block
# indefinitely when the underlying transport is wedged — and a wedged FC HBA
# is exactly the situation in which this module gets called. get_fc_targets()
# runs from activate_storage() on the pvestatd path, so an unbounded read here
# stalls the whole poll cycle.
sub _read_file {
    my ($path, $timeout) = @_;
    return undef unless -e $path;
    my $content = sysfs_read_with_timeout($path, $timeout // 3);
    return undef unless defined $content;
    chomp($content);
    return length($content) ? $content : undef;
}

# Format WWN from 0x format to colon-separated format
# Input:  0x5001438032a5b6c7 or 5001438032a5b6c7
# Output: 50:01:43:80:32:a5:b6:c7
sub format_wwn {
    my ($wwn) = @_;
    return undef unless defined $wwn;

    # Remove 0x prefix if present
    $wwn =~ s/^0x//i;

    # Remove any existing colons or spaces
    $wwn =~ s/[:\s]//g;

    # Validate length (16 hex chars = 8 bytes)
    return undef unless $wwn =~ /^[0-9a-fA-F]{16}$/;

    # Insert colons every 2 characters
    $wwn = lc($wwn);
    $wwn =~ s/(..)(?=.)/$1:/g;

    return $wwn;
}

# Parse WWN to raw format (no colons, lowercase)
# Input:  50:01:43:80:32:a5:b6:c7 or 0x5001438032a5b6c7
# Output: 5001438032a5b6c7
sub parse_wwn {
    my ($wwn) = @_;
    return undef unless defined $wwn;

    # Remove 0x prefix if present
    $wwn =~ s/^0x//i;

    # Remove colons, dashes, and spaces
    $wwn =~ s/[:\-\s]//g;

    # Validate and return lowercase
    return undef unless $wwn =~ /^[0-9a-fA-F]{16}$/;
    return lc($wwn);
}

# Normalize WWN for comparison (lowercase, no separators)
# This allows comparing WWNs regardless of their original format
sub normalize_wwn {
    my ($wwn) = @_;
    return parse_wwn($wwn);
}

# Compare two WWNs (format-agnostic)
sub wwn_equal {
    my ($wwn1, $wwn2) = @_;
    my $n1 = normalize_wwn($wwn1);
    my $n2 = normalize_wwn($wwn2);
    return 0 unless defined $n1 && defined $n2;
    return $n1 eq $n2;
}

# Check if FC HBA is available on this system
sub is_fc_available {
    return -d FC_HOST_PATH && scalar(@{get_fc_hosts()}) > 0;
}

# Get list of FC host adapters
# Returns: arrayref of host names (e.g., ['host0', 'host1'])
sub get_fc_hosts {
    my @hosts;

    return [] unless -d FC_HOST_PATH;

    opendir(my $dh, FC_HOST_PATH) or return [];
    for my $entry (readdir($dh)) {
        next if $entry =~ /^\./;
        # Captured, not just matched: readdir() output is tainted under -T,
        # and these names end up in sysfs write paths (rescan_fc_hosts).
        my ($host) = $entry =~ /^(host\d+)$/ or next;

        # Verify it's a valid FC host by checking port_name exists
        my $port_name_file = FC_HOST_PATH . "/$host/port_name";
        if (-r $port_name_file) {
            push @hosts, $host;
        }
    }
    closedir($dh);

    # Sort by host number
    @hosts = sort {
        my ($a_num) = $a =~ /(\d+)/;
        my ($b_num) = $b =~ /(\d+)/;
        $a_num <=> $b_num;
    } @hosts;

    return \@hosts;
}

# Get FC HBA port WWPNs (World Wide Port Names)
# Returns: arrayref of WWPNs in colon-separated format
# Example: ['50:01:43:80:32:a5:b6:c7', '50:01:43:80:32:a5:b6:c8']
sub get_fc_wwpns {
    my (%opts) = @_;

    my @wwpns;
    my $hosts = get_fc_hosts();

    for my $host (@$hosts) {
        my $port_name_file = FC_HOST_PATH . "/$host/port_name";
        my $port_state_file = FC_HOST_PATH . "/$host/port_state";

        # Read port name (WWPN)
        my $wwpn_raw = _read_file($port_name_file);
        next unless $wwpn_raw;

        # Check port state if requested
        if ($opts{online_only}) {
            my $state = _read_file($port_state_file) // '';
            next unless $state =~ /online/i;
        }

        my $wwpn = format_wwn($wwpn_raw);
        push @wwpns, $wwpn if $wwpn;
    }

    return \@wwpns;
}

# Get FC HBA port WWPNs in raw format (no colons, for Pure Storage API)
# Returns: arrayref of WWPNs without separators
# Example: ['5001438032a5b6c7', '5001438032a5b6c8']
sub get_fc_wwpns_raw {
    my (%opts) = @_;

    my @raw_wwpns;
    my $hosts = get_fc_hosts();

    for my $host (@$hosts) {
        my $port_name_file = FC_HOST_PATH . "/$host/port_name";

        my $wwpn_raw = _read_file($port_name_file);
        next unless $wwpn_raw;

        # Check port state if requested
        if ($opts{online_only}) {
            my $state = _read_file(FC_HOST_PATH . "/$host/port_state") // '';
            next unless $state =~ /online/i;
        }

        # Parse directly from sysfs format (0x...) to raw lowercase hex
        my $raw = parse_wwn($wwpn_raw);
        push @raw_wwpns, $raw if $raw;
    }

    return \@raw_wwpns;
}

# Get FC HBA node WWNNs (World Wide Node Names)
# Returns: arrayref of WWNNs in colon-separated format
sub get_fc_wwnn {
    my (%opts) = @_;

    my @wwnns;
    my $hosts = get_fc_hosts();

    for my $host (@$hosts) {
        my $node_name_file = FC_HOST_PATH . "/$host/node_name";

        my $wwnn_raw = _read_file($node_name_file);
        next unless $wwnn_raw;

        my $wwnn = format_wwn($wwnn_raw);
        push @wwnns, $wwnn if $wwnn;
    }

    # Return unique WWNNs (multiple ports may share same node name)
    my %seen;
    @wwnns = grep { !$seen{$_}++ } @wwnns;

    return \@wwnns;
}

# Get detailed FC host information
# Returns: arrayref of hashrefs with host details
sub get_fc_host_info {
    my @info;
    my $hosts = get_fc_hosts();

    for my $host (@$hosts) {
        my $base = FC_HOST_PATH . "/$host";

        my $port_name = _read_file("$base/port_name");
        my $node_name = _read_file("$base/node_name");
        my $port_state = _read_file("$base/port_state") // 'unknown';
        my $port_type = _read_file("$base/port_type") // 'unknown';
        my $speed = _read_file("$base/speed") // 'unknown';
        my $fabric_name = _read_file("$base/fabric_name");

        push @info, {
            host        => $host,
            wwpn        => format_wwn($port_name),
            wwnn        => format_wwn($node_name),
            port_state  => $port_state,
            port_type   => $port_type,
            speed       => $speed,
            fabric_name => format_wwn($fabric_name),
        };
    }

    return \@info;
}

# Rescan FC hosts for new LUNs
# This triggers a LIP (Loop Initialization Primitive) or fabric rescan
sub rescan_fc_hosts {
    my (%opts) = @_;

    my $hosts = get_fc_hosts();
    my $rescanned = 0;

    # Issue LIP and SCSI scan use sysfs_write_with_timeout (not bare
    # open()) — even though we filter to FC hosts only (which is the
    # categorical safety from to_pure5 Bug 1), the write itself can
    # still hang in the kernel if the FC HBA is wedged. Bare open()
    # blocks the parent worker; the timeout-bounded helper at least
    # returns control after 10s and lets the caller move on.
    #
    # Note: D-state children still cannot be killed by SIGKILL — see
    # the rescan_scsi_hosts() comment in Multipath.pm. The categorical
    # protection here is that we ONLY iterate hosts already in
    # @$hosts (returned by get_fc_hosts() which queries
    # /sys/class/fc_host/), so we never touch a non-FC HBA.
    # LIP is OPT-IN and off by default. It is a link reset, not a lookup.
    #
    # Issuing a Loop Initialization Primitive forces every device behind that
    # HBA port to re-login — including LUNs belonging to other storage on the
    # same HBA. It is the right tool for "a target port appeared or the link
    # changed", and the wrong tool for "the array mapped me a new LUN".
    #
    # This function used to issue a LIP unconditionally, and it is called from
    # tight loops: path()'s retry loop (every 2s), alloc_image()'s wait loop
    # (every 3s), wait_for_multipath_device()'s fc_rescan callback (every
    # round) and, before v1.1.22, activate_storage() on every pvestatd poll
    # (every 10s). That is a repeated fabric-wide link reset in exchange for
    # nothing: the SCSI host scan below is what actually discovers a newly
    # mapped LUN, via REPORT_LUNS on the existing session.
    #
    # Pass lip => 1 only when a target port itself is expected to have
    # changed, and never from a polling loop.
    if ($opts{lip}) {
        for my $host (@$hosts) {
            my $issue_lip_file = FC_HOST_PATH . "/$host/issue_lip";
            if (-w $issue_lip_file) {
                if (sysfs_write_with_timeout($issue_lip_file, "1\n", 10)) {
                    $rescanned++;
                } else {
                    warn "Failed to issue LIP on $host (timeout or error)\n";
                }
            }
        }
    }

    # Trigger SCSI host scan only for FC-related hosts. Source the
    # name list from get_fc_hosts() so we never touch a non-FC HBA.
    my $scsi_host_path = '/sys/class/scsi_host';
    if (-d $scsi_host_path) {
        for my $host (@$hosts) {
            my $scan_file = "$scsi_host_path/$host/scan";
            if (-w $scan_file) {
                $rescanned++ if sysfs_write_with_timeout($scan_file, "- - -\n", 10);
            }
        }
    }

    # Give the kernel time to discover devices
    sleep($opts{delay} // 2);

    return $rescanned;
}

# Get FC remote port (target) information
# Returns: arrayref of hashrefs with target details
#
# The kernel names these "rport-<host>:<channel>-<number>" (scsi_transport_fc:
# dev_set_name(dev, "rport-%d:%d-%d", ...)), e.g. rport-3:0-1. This used to
# match /^rport-\d+:\d+-\d+$/, which no kernel ever produces, so the list was
# always empty and activate_storage() warned "No FC target ports detected" on
# every FC node with working zoning -- sending operators to check a fabric
# that was fine. $root is for tests only.
sub get_fc_targets {
    my ($root) = @_;
    $root //= FC_REMOTE_PATH;
    my @targets;

    return [] unless -d $root;

    opendir(my $dh, $root) or return [];
    for my $entry (readdir($dh)) {
        next if $entry =~ /^\./;
        next unless $entry =~ /^rport-\d+:\d+-\d+$/;

        my $base = "$root/$entry";

        my $port_name = _read_file("$base/port_name");
        my $node_name = _read_file("$base/node_name");
        my $port_state = _read_file("$base/port_state") // 'unknown';
        my $roles = _read_file("$base/roles") // '';

        push @targets, {
            rport       => $entry,
            wwpn        => format_wwn($port_name),
            wwnn        => format_wwn($node_name),
            port_state  => $port_state,
            roles       => $roles,
            is_target   => ($roles =~ /target/i) ? 1 : 0,
        };
    }
    closedir($dh);

    return \@targets;
}

1;

__END__

=head1 NAME

PVE::Storage::Custom::PureStorage::FC - Fibre Channel HBA management utilities

=head1 SYNOPSIS

    use PVE::Storage::Custom::PureStorage::FC qw(
        get_fc_wwpns
        is_fc_available
        rescan_fc_hosts
    );

    # Check if FC is available
    if (is_fc_available()) {
        # Get local FC HBA WWPNs
        my $wwpns = get_fc_wwpns();
        # Returns: ['50:01:43:80:32:a5:b6:c7', ...]

        # Rescan for new LUNs
        rescan_fc_hosts();
    }

=head1 DESCRIPTION

This module provides Fibre Channel HBA management utilities for the Pure Storage
storage plugin. It reads FC HBA information from /sys/class/fc_host
and provides functions for WWPN retrieval and LUN rescanning.

=head1 FUNCTIONS

=over 4

=item B<is_fc_available()>

Returns true if FC HBAs are available on the system.

=item B<get_fc_wwpns(%opts)>

Returns arrayref of WWPNs in colon-separated format.
Options: online_only => 1 to return only online ports.

=item B<get_fc_wwnn()>

Returns arrayref of WWNNs (node names) in colon-separated format.

=item B<get_fc_hosts()>

Returns arrayref of FC host names (e.g., ['host0', 'host1']).

=item B<rescan_fc_hosts(%opts)>

Triggers a SCSI host scan for new LUNs on every FC host.
Options: delay => seconds to wait after the scan; lip => 1 to additionally
issue a Loop Initialization Primitive. LIP is a disruptive link reset and is
NOT needed to discover newly mapped LUNs — leave it off unless a target port
itself is expected to have changed, and never enable it in a polling loop.

=item B<format_wwn($wwn)>

Converts WWN to colon-separated format.

=back

=cut
