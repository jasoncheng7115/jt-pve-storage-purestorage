# Pure Storage iSCSI Management Utilities
# Copyright (c) 2026 Jason Cheng (Jason Tools)
# Licensed under the MIT License

package PVE::Storage::Custom::PureStorage::ISCSI;

use strict;
use warnings;

use PVE::Storage::Custom::PureStorage::Multipath ();

use Carp qw(croak);
use IO::Select;
use IO::Socket::INET;
use IPC::Open3;
use POSIX ();
use Symbol qw(gensym);

use Exporter qw(import);

our @EXPORT_OK = qw(
    get_initiator_name
    probe_portal
    discover_targets
    login_target
    logout_target
    get_sessions
    get_session_states
    rescan_sessions
    is_portal_logged_in
);

# Constants
use constant {
    INITIATOR_NAME_FILE => '/etc/iscsi/initiatorname.iscsi',
    ISCSIADM            => '/usr/bin/iscsiadm',
    DISCOVERY_TIMEOUT   => 30,
    LOGIN_TIMEOUT       => 60,
    DEVICE_WAIT_TIMEOUT => 30,
    DEVICE_WAIT_INTERVAL => 1,
};

# Read file content
sub _read_file {
    my ($path) = @_;
    open(my $fh, '<', $path) or croak "Cannot open $path: $!";
    local $/;
    my $content = <$fh>;
    close($fh);
    return $content;
}

# Write file content
sub _write_file {
    my ($path, $content) = @_;
    open(my $fh, '>', $path) or croak "Cannot open $path for writing: $!";
    print $fh $content;
    close($fh);
    return 1;
}

# NOTE on alarm(): this module arms alarm() in several places and clears it
# with alarm(0). A bare alarm(0) also cancels any alarm the CALLER had armed,
# silently disarming their watchdog. PVE's own PVE::Tools::run_with_timeout
# avoids that with `my $prev = alarm 0; ... alarm $prev`, and the three
# funnels below (_run_cmd, sysfs_read_with_timeout) now do the same, so the
# hot paths are safe. Proxmox VE does not currently invoke storage plugins
# from inside an alarm — lock_file_full() arms one only around acquiring the
# lock, not around the callback — so the remaining sites are latent rather
# than live. Any NEW alarm use should save and restore.

# Reap a child that blew through its alarm budget, WITHOUT ever blocking.
#
# `kill('TERM'); waitpid($pid, 0);` blocks forever when the child is stuck in
# uninterruptible sleep — which is precisely the iscsiadm-against-a-dead-path
# case this timeout exists for (see rescan_sessions). Our alarm has already
# fired and been cleared by then, so nothing would break us out again.
# Escalate TERM -> KILL, reap only with WNOHANG on a bounded poll, and leave
# an unreapable child to init rather than joining it in D state.
sub _reap_timed_out_child {
    my ($pid, $cmd) = @_;
    return unless $pid;

    for my $sig ('TERM', 'KILL') {
        kill($sig, $pid);
        my $deadline = time() + 2;
        while (time() < $deadline) {
            my $res = waitpid($pid, POSIX::WNOHANG());
            return if $res != 0;   # reaped, or already gone
            select(undef, undef, undef, 0.1);
        }
    }

    warn "child pid $pid for '@{$cmd // []}' did not die after TERM+KILL "
        . "(likely uninterruptible sleep in the kernel); leaving it to init\n";
}

# Run a command and return output
sub _run_cmd {
    my ($cmd, %opts) = @_;

    # pvedaemon and pveproxy run with -T; a value read from sysfs or off the
    # network cannot reach exec untainted. See Multipath::untaint_arg.
    $cmd = [ map { PVE::Storage::Custom::PureStorage::Multipath::untaint_arg($_) } @$cmd ];

    my $timeout = $opts{timeout} // 30;

    my ($stdout, $stderr) = ('', '');
    my $err = gensym;
    my $pid;

    my $prev_alarm = alarm(0);   # suspend and remember any caller alarm
    eval {
        local $SIG{ALRM} = sub { die "timeout\n" };
        alarm($timeout);

        $pid = open3(my $in, my $out, $err, @$cmd);
        close($in);

        # Use IO::Select to read stdout and stderr simultaneously
        # to avoid deadlock when stderr buffer fills up
        my $sel = IO::Select->new($out, $err);
        while (my @ready = $sel->can_read()) {
            for my $fh (@ready) {
                my $buf;
                my $bytes = sysread($fh, $buf, 8192);
                if (!defined($bytes) || $bytes == 0) {
                    $sel->remove($fh);
                    next;
                }
                if ($fh == $out) {
                    $stdout .= $buf;
                } else {
                    $stderr .= $buf;
                }
            }
        }

        # Covered by the alarm armed above: SIGALRM interrupts waitpid and
        # the handler dies, landing us in the timeout branch below, which
        # reaps without blocking. Do not "fix" this into WNOHANG polling.
        waitpid($pid, 0);  ## audit-ok: A6 - bounded by the alarm armed above; the
                           ## handler routes to _reap_timed_out_child, which uses WNOHANG.
        alarm(0);
    };

    if ($@) {
        alarm($prev_alarm);
        if ($@ eq "timeout\n") {
            _reap_timed_out_child($pid, $cmd);
            croak "Command timed out after ${timeout}s: @$cmd";
        }
        croak "Command failed: $@";
    }
    alarm($prev_alarm);

    my $exit_code = $? >> 8;

    if ($exit_code != 0 && !$opts{ignore_errors}) {
        unless ($opts{allow_nonzero}) {
            croak "Command failed (exit $exit_code): @$cmd\nstderr: $stderr";
        }
    }

    return wantarray ? ($stdout, $stderr, $exit_code) : $stdout;
}

# Get the local initiator name (IQN)
sub get_initiator_name {
    my $content = _read_file(INITIATOR_NAME_FILE);

    if ($content =~ /InitiatorName\s*=\s*(\S+)/) {
        return $1;
    }

    croak "Failed to parse initiator name from " . INITIATOR_NAME_FILE;
}

# Quick TCP connectivity probe to an iSCSI portal. Returns 1 if the host
# can establish a TCP connection to ($ip, $port) within $timeout seconds,
# 0 otherwise. Used to skip unreachable portals BEFORE invoking iscsiadm,
# which has 30s discovery + 60s login timeouts that compound badly when
# the array exposes more iSCSI ports than this host can physically reach
# (asymmetric cabling, controller ports on a different network segment,
# partial fabric outage).
sub probe_portal {
    my ($ip, $port, %opts) = @_;

    croak "ip is required" unless $ip;
    $port //= 3260;
    my $timeout = $opts{timeout} // 2;

    my $reachable = 0;
    eval {
        local $SIG{ALRM} = sub { die "timeout\n" };
        alarm($timeout);

        my $sock = IO::Socket::INET->new(
            PeerAddr => $ip,
            PeerPort => $port,
            Proto    => 'tcp',
            Timeout  => $timeout,
        );
        if ($sock) {
            $reachable = 1;
            $sock->close();
        }
        alarm(0);
    };
    alarm(0);

    return $reachable;
}

# Discover iSCSI targets on a portal
sub discover_targets {
    my ($portal, %opts) = @_;

    croak "portal is required" unless $portal;

    my $port = $opts{port} // 3260;
    my $portal_addr = "$portal:$port";

    my ($stdout) = _run_cmd(
        [ISCSIADM, '-m', 'discovery', '-t', 'sendtargets', '-p', $portal_addr],
        timeout => $opts{timeout} // DISCOVERY_TIMEOUT,
        allow_nonzero => 1,  # May return non-zero if already discovered
    );

    my @targets;
    for my $line (split /\n/, $stdout) {
        # Format: portal,portal_group target_name
        if ($line =~ /^(\S+),\d+\s+(\S+)/) {
            push @targets, {
                portal => $1,
                target => $2,
            };
        }
    }

    return \@targets;
}

# Login to an iSCSI target
sub login_target {
    my ($portal, $target, %opts) = @_;

    croak "portal is required" unless $portal;
    croak "target is required" unless $target;

    my $port = $opts{port} // 3260;
    my $portal_addr = "$portal:$port";

    # Check if already logged in to THIS specific portal.
    # Pure Storage iSCSI LIFs share the same target IQN across multiple
    # controller ports, so checking by target name alone would falsely skip
    # subsequent portals after the first login succeeded — leaving us with
    # only one multipath path instead of N. Always check (portal, target).
    if (is_portal_logged_in($portal_addr, $target)) {
        return 1;
    }

    # Set login parameters if CHAP is configured
    if ($opts{chap_username}) {
        _run_cmd([ISCSIADM, '-m', 'node', '-T', $target, '-p', $portal_addr,
                  '-o', 'update', '-n', 'node.session.auth.authmethod', '-v', 'CHAP']);
        _run_cmd([ISCSIADM, '-m', 'node', '-T', $target, '-p', $portal_addr,
                  '-o', 'update', '-n', 'node.session.auth.username', '-v', $opts{chap_username}]);
        _run_cmd([ISCSIADM, '-m', 'node', '-T', $target, '-p', $portal_addr,
                  '-o', 'update', '-n', 'node.session.auth.password', '-v', $opts{chap_password}]);
    }

    # Enable automatic login on boot
    _run_cmd([ISCSIADM, '-m', 'node', '-T', $target, '-p', $portal_addr,
              '-o', 'update', '-n', 'node.startup', '-v', 'automatic'],
             allow_nonzero => 1);

    # Enable session auto-recovery after a transient outage (e.g. Pure
    # controller failover, switch reload). Default is 120s in iscsid.conf
    # but the per-node value may be lower if iscsid was reconfigured later.
    # Set explicitly so behaviour is deterministic.
    _run_cmd([ISCSIADM, '-m', 'node', '-T', $target, '-p', $portal_addr,
              '-o', 'update', '-n', 'node.session.timeo.replacement_timeout', '-v', '120'],
             allow_nonzero => 1);

    # Login
    my ($stdout, $stderr, $exit) = _run_cmd(
        [ISCSIADM, '-m', 'node', '-T', $target, '-p', $portal_addr, '-l'],
        timeout => $opts{timeout} // LOGIN_TIMEOUT,
        allow_nonzero => 1,
    );

    # Exit code 15 means already logged in
    if ($exit != 0 && $exit != 15) {
        croak "Failed to login to target $target: $stderr";
    }

    return 1;
}

# Logout from an iSCSI target
sub logout_target {
    my ($portal, $target, %opts) = @_;

    croak "portal is required" unless $portal;
    croak "target is required" unless $target;

    my $port = $opts{port} // 3260;
    my $portal_addr = "$portal:$port";

    my ($stdout, $stderr, $exit) = _run_cmd(
        [ISCSIADM, '-m', 'node', '-T', $target, '-p', $portal_addr, '-u'],
        allow_nonzero => 1,
    );

    # Exit code 21 means not logged in
    if ($exit != 0 && $exit != 21) {
        croak "Failed to logout from target $target: $stderr";
    }

    return 1;
}

# Get all active iSCSI sessions
sub get_sessions {
    my (%opts) = @_;

    my ($stdout, $stderr, $exit) = _run_cmd(
        [ISCSIADM, '-m', 'session'],
        allow_nonzero => 1,
    );

    # Exit code 21 means no active sessions
    return [] if $exit == 21;

    my @sessions;
    for my $line (split /\n/, $stdout) {
        # Format: protocol: [session_id] portal target
        if ($line =~ /^(\w+):\s+\[(\d+)\]\s+(\S+)\s+(\S+)/) {
            push @sessions, {
                protocol   => $1,
                session_id => $2,
                portal     => $3,
                target     => $4,
            };
        }
    }

    return \@sessions;
}

# Report every kernel-visible iSCSI session and its state, read straight from
# /sys/class/iscsi_session/ with bounded reads. Unlike get_sessions() this does
# NOT shell out to iscsiadm, so it stays usable exactly when iscsiadm is the
# thing that is wedged — which is when a diagnostic is most needed.
#
# Returns an arrayref of { session, state, target, portal }, where state is the
# kernel session state (LOGGED_IN / FAILED / FREE / ...) or undef if unreadable.
# rescan_sessions() only rescans LOGGED_IN sessions, so this is the fastest way
# to tell "the rescan was skipped" apart from "the rescan found nothing".
sub get_session_states {
    my @out;

    my @sessions;
    eval {
        local $SIG{ALRM} = sub { die "timeout\n" };
        alarm(5);
        opendir(my $dh, '/sys/class/iscsi_session') or die "opendir: $!\n";
        @sessions = sort grep { /^session\d+$/ } readdir($dh);
        closedir($dh);
        alarm(0);
    };
    alarm(0);
    return \@out if $@;

    for my $s (@sessions) {
        my $base = "/sys/class/iscsi_session/$s";
        push @out, {
            session => $s,
            state   => _read_sysfs_attr("$base/state", 2),
            target  => _read_sysfs_attr("$base/targetname", 2),
            portal  => _read_sysfs_attr("$base/persistent_address", 2),
        };
    }

    return \@out;
}

# Check if a session is open to a SPECIFIC (portal, target) pair.
# This is the correct check before logging in to a Pure Storage iSCSI portal,
# because all Pure controller LIFs serving the same target share one IQN.
sub is_portal_logged_in {
    my ($portal_addr, $target, $sessions) = @_;

    # Accept a pre-fetched session list so a caller iterating many portals
    # can snapshot `iscsiadm -m session` ONCE before the loop instead of
    # shelling out per portal (each call is an unbounded external command).
    $sessions //= get_sessions();
    for my $session (@$sessions) {
        next unless $session->{target} eq $target;
        # iscsiadm -m session reports portal as "ip:port,tpgt"; strip the
        # trailing portal-group tag for comparison.
        my $sess_portal = $session->{portal};
        $sess_portal =~ s/,\d+$//;
        return 1 if $sess_portal eq $portal_addr;
    }

    return 0;
}

# Rescan all iSCSI sessions for new LUNs
# Rescan iSCSI sessions. Enumerates sessions via /sys/class/iscsi_session/
# (kernel-maintained, immune to iscsiadm hangs), then issues a per-session
# rescan only on sessions whose state is LOGGED_IN.
#
# Why not `iscsiadm -m session --rescan`: that command rescans ALL active
# sessions in a single iscsiadm invocation. When some paths are dead
# (typical field scenario: 4-portal Pure with 2 paths broken), the rescan
# triggers SCSI bus commands on the dead sessions. The kernel waits for
# the SCSI bus timeout per dead path (often 30s+ each, sometimes much
# longer), which exceeds the iscsiadm parent timeout. The parent gets
# killed, leaving D-state children behind (kernel-locked, immortal —
# see CLAUDE.md lesson #3). Every subsequent pvestatd poll fires another
# rescan and stacks more D-state children, eventually wedging pvestatd,
# pvedaemon, and the entire node management plane (web UI shows "?" for
# every storage).
#
# Field reproducer (issue #5, @pulipulichen): 4-LIF Pure with 2 paths
# broken; VM snapshot WITH memory triggers VMSTATE volume creation;
# alloc_image's wait-for-device loop calls rescan_sessions repeatedly;
# node dies. CT snapshot and VM snapshot WITHOUT memory don't repro
# because they don't create a new volume that needs host-side activation.
#
# Behaviour:
#   - Sessions in FREE / REOPEN / FAILED / etc. states are SKIPPED.
#   - Only LOGGED_IN sessions are rescanned, one at a time, each with
#     a bounded timeout (default 10s vs old monolithic 60s for all).
#   - Worst-case orphan child count is 1 per (LOGGED_IN-but-stuck) session
#     per call, instead of accumulating against `--rescan` of all sessions.
#   - Returns the number of sessions successfully rescanned. Never croaks
#     on per-session failures; the wait-for-device loop above us handles
#     "device didn't appear" with its own timeout.
sub rescan_sessions {
    my (%opts) = @_;
    my $per_session_timeout = $opts{per_session_timeout} // $opts{timeout} // 10;

    my @sessions;
    eval {
        local $SIG{ALRM} = sub { die "timeout\n" };
        alarm(5);
        opendir(my $dh, '/sys/class/iscsi_session') or die "opendir: $!\n";
        @sessions = sort grep { /^session\d+$/ } readdir($dh);
        closedir($dh);
        alarm(0);
    };
    alarm(0);
    if ($@) {
        # No iSCSI configured at all is fine; bubble up real errors.
        return 0 if $@ =~ /No such file or directory/;
        warn "rescan_sessions: cannot enumerate iSCSI sessions: $@";
        return 0;
    }
    return 0 unless @sessions;

    my $rescanned = 0;
    my $skipped_state = 0;
    my $rescan_failed = 0;
    my @skipped_states;

    for my $session (@sessions) {
        my ($sid) = $session =~ /^session(\d+)$/ or next;

        my $state = _read_sysfs_attr("/sys/class/iscsi_session/$session/state", 2);
        if (!defined $state) {
            # Cannot read state — be conservative and skip rather than
            # rescan a session whose kernel state we don't know.
            $skipped_state++;
            next;
        }
        unless ($state eq 'LOGGED_IN') {
            $skipped_state++;
            push @skipped_states, "$session=$state";
            next;
        }

        my ($stdout, $stderr, $exit) = _run_cmd(
            [ISCSIADM, '-m', 'session', '-r', $sid, '--rescan'],
            allow_nonzero => 1,
            timeout => $per_session_timeout,
        );
        if ($exit == 0) {
            $rescanned++;
        } else {
            $rescan_failed++;
        }
    }

    if ($skipped_state > 0) {
        warn "rescan_sessions: skipped $skipped_state non-LOGGED_IN iSCSI " .
             "session(s) [" . join(', ', @skipped_states) . "], " .
             "rescanned $rescanned, failed $rescan_failed\n";
    }

    return $rescanned;
}

# Bounded read of a single sysfs attribute. Returns the stripped value or
# undef on timeout/error. Used by rescan_sessions to read session state
# without risking a kernel-side hang on a stuck iSCSI host.
sub _read_sysfs_attr {
    my ($path, $timeout) = @_;
    $timeout //= 2;
    my $val;
    eval {
        local $SIG{ALRM} = sub { die "timeout\n" };
        alarm($timeout);
        open(my $fh, '<', $path) or die "open: $!\n";
        $val = <$fh>;
        close($fh);
        alarm(0);
    };
    alarm(0);
    return undef if $@;
    return undef unless defined $val;
    chomp $val;
    return $val;
}

# Rescan a specific target
sub rescan_target {
    my ($target, %opts) = @_;

    croak "target is required" unless $target;

    my ($stdout, $stderr, $exit) = _run_cmd(
        [ISCSIADM, '-m', 'node', '-T', $target, '--rescan'],
        allow_nonzero => 1,
        timeout => $opts{timeout} // 60,
    );

    return 1 if $exit == 0;
    croak "Failed to rescan target $target: $stderr";
}

# Untaint a device path for taint mode compatibility
sub _untaint_device_path {
    my ($path) = @_;
    return undef unless defined $path;
    # Allow paths like: /dev/sda, /dev/mapper/3600a0980..., /dev/disk/by-id/...
    if ($path =~ m|^(/dev/[a-zA-Z0-9_\-/\.]+)$|) {
        return $1;
    }
    return undef;
}

# Find multipath device by LUN serial
sub _find_multipath_device {
    my ($serial) = @_;

    # Use multipathd to query devices
    my ($stdout, $stderr, $exit) = _run_cmd(
        # Absolute, resolved: a Proxmox VE daemon has no PATH, so exec falls
        # back to /bin:/usr/bin and multipathd lives in /usr/sbin.
        [PVE::Storage::Custom::PureStorage::Multipath::multipathd_path(),
         'show', 'maps', 'raw', 'format', '%n %w'],
        allow_nonzero => 1,
        ignore_errors => 1,
    );

    return undef unless defined $stdout;

    for my $line (split /\n/, $stdout) {
        my ($name, $wwid) = split /\s+/, $line, 2;
        next unless $name && $wwid;

        # Check if WWID ends with the serial (Pure WWID = 3624a9370 + serial)
        if ($wwid && lc($wwid) =~ /\Q$serial\E$/i) {
            # Untaint the device path for taint mode compatibility
            return _untaint_device_path("/dev/mapper/$name");
        }
    }

    return undef;
}

# Get device path by serial number
sub get_device_by_serial {
    my ($serial, %opts) = @_;

    croak "serial is required" unless $serial;

    # First try multipath
    my $mpath = _find_multipath_device($serial);
    return $mpath if $mpath;  # Already untainted

    # Fall back to /dev/disk/by-id (exact suffix match).
    # Wrap in alarm to bound the glob in case devtmpfs / udev wedges.
    my $found;
    eval {
        local $SIG{ALRM} = sub { die "timeout\n" };
        alarm(5);
        my @devices = grep { /\Q$serial\E$/i } glob("/dev/disk/by-id/scsi-*");
        $found = $devices[0] if @devices;
        alarm(0);
    };
    alarm(0);
    if ($@ && $@ eq "timeout\n") {
        warn "get_device_by_serial: /dev/disk/by-id glob timed out after 5s\n";
        return undef;
    }

    return $found ? _untaint_device_path($found) : undef;
}

# Remove iSCSI node configuration
sub delete_node {
    my ($portal, $target, %opts) = @_;

    croak "portal is required" unless $portal;
    croak "target is required" unless $target;

    my $port = $opts{port} // 3260;
    my $portal_addr = "$portal:$port";

    my ($stdout, $stderr, $exit) = _run_cmd(
        [ISCSIADM, '-m', 'node', '-T', $target, '-p', $portal_addr, '-o', 'delete'],
        allow_nonzero => 1,
    );

    return 1;
}

1;

__END__

=head1 NAME

PVE::Storage::Custom::PureStorage::ISCSI - iSCSI management utilities

=head1 SYNOPSIS

    use PVE::Storage::Custom::PureStorage::ISCSI qw(
        get_initiator_name
        discover_targets
        login_target
    );

    # Get local initiator IQN
    my $iqn = get_initiator_name();

    # Discover targets
    my $targets = discover_targets('192.168.1.100');

    # Login to target
    login_target('192.168.1.100', $targets->[0]{target});

=head1 DESCRIPTION

This module provides iSCSI management utilities for the Pure Storage
storage plugin. It wraps the iscsiadm command-line tool.

=cut
